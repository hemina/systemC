#include <systemc.h>
#include "top.h"

void TOP::COMPORTEMENT()
{
}

