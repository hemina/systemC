#include <systemc.h>
#include "fft.h"

void FFT::COMPORTEMENT()
{
	/*float data;
  	if (file.is_open())
	{
 		while(file >> data)
 		{
			O.write(data);
      			//cout << data << '\n';
			wait();
   		}

    		file.close();
		while(true)
			wait();
	}*/
}

