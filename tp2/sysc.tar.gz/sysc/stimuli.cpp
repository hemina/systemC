#include <systemc.h>
#include "stimuli.h"

void STIMULI::STIM()
{
	wait();
}

