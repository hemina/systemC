#ifndef TOP_H
#define TOP_H
#include <systemc.h>
#include <input.h>
#include <output.h>

using namespace std;

SC_MODULE(TOP)
{
	sc_fifo<float>	O;
	sc_in<bool>	CLK;

	sc_signal<bool>	clk;
	sc_fifo<float> fifo;
	INPUT in;
	OUTPUT out;

	void COMPORTEMENT();

	SC_CTOR(TOP) : in("input"), out("output"), fifo("fifo", 16)
	{
		in.CLK(CLK);
		out.CLK(CLK);
		in.O(fifo);
		out.I(fifo);

		SC_METHOD(COMPORTEMENT);
		sensitive << CLK;
	}
};

#endif
