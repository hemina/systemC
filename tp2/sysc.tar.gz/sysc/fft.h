#ifndef FFT_H
#define FFT_H
#include <systemc.h>

using namespace std;

SC_MODULE(FFT)
{
	sc_fifo_out<float>	O;
	sc_fifo_in<float>	I;
	sc_in<bool>		CLK;

	void COMPORTEMENT();

	SC_CTOR(FFT)
	{
		SC_THREAD(COMPORTEMENT);
		sensitive << CLK.pos();
	}
};

#endif
